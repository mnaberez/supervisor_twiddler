supervisor_twiddler:
  This package is an RPC extension for the supervisor2 package that
  facilitates manipulation of supervisor's configuration and state in ways	
  that are not normally accessible at runtime.

Home Page
  "supervisor_twiddler":http://maintainable.com/software/supervisor_twiddler
  
Author Information

  Mike Naberezny (mike@maintainable.com)
  "Maintainable Software":http://maintainable.com
